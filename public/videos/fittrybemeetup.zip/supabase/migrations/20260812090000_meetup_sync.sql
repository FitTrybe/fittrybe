-- Fittrybe -> Meetup sync
-- Adds the columns the edge function reads and writes back to.

alter table public.sessions
  add column if not exists meetup_event_id       text,
  add column if not exists meetup_event_url      text,
  add column if not exists meetup_venue_id       text,
  add column if not exists meetup_synced_at      timestamptz,
  add column if not exists meetup_sync_error     text;

create unique index if not exists sessions_meetup_event_id_key
  on public.sessions (meetup_event_id)
  where meetup_event_id is not null;

comment on column public.sessions.meetup_venue_id is
  'Meetup venue id for this session location. Falls back to MEETUP_DEFAULT_VENUE_ID env var.';

-- Optional: reusable venue mapping so hosts pick a pitch/gym once and it maps to a Meetup venue.
create table if not exists public.meetup_venues (
  id              uuid primary key default gen_random_uuid(),
  fittrybe_venue  text not null unique,
  meetup_venue_id text not null,
  created_at      timestamptz not null default now()
);

alter table public.meetup_venues enable row level security;

create policy "meetup_venues readable by authenticated"
  on public.meetup_venues for select
  to authenticated
  using (true);
