// POST /functions/v1/publish-to-meetup   { "sessionId": "<uuid>" }
//
// Takes a Fittrybe session, pushes it to Meetup as a published event,
// and writes the Meetup event id + url back onto the session row.

import { createClient } from "npm:@supabase/supabase-js@2";
import {
  createAndPublishEvent,
  credsFromEnv,
  getAccessToken,
  updateEvent,
} from "./meetup.ts";

const CORS = {
  "Access-Control-Allow-Origin": Deno.env.get("SITE_ORIGIN") ?? "*",
  "Access-Control-Allow-Headers": "authorization, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, "Content-Type": "application/json" },
  });

interface SessionRow {
  id: string;
  host_id: string;
  title: string;
  sport: string | null;
  description: string | null;
  starts_at: string; // timestamptz
  duration_minutes: number | null;
  capacity: number | null;
  price_pence: number | null;
  location_name: string | null;
  city: string | null;
  timezone: string | null;
  meetup_event_id: string | null;
  meetup_venue_id: string | null;
}

/** Meetup wants local wall clock time with no offset: 2026-08-20T18:00 */
function toMeetupLocal(iso: string, timeZone: string): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(new Date(iso));
  const p = Object.fromEntries(parts.map((x) => [x.type, x.value]));
  const hour = p.hour === "24" ? "00" : p.hour;
  return `${p.year}-${p.month}-${p.day}T${hour}:${p.minute}`;
}

function buildDescription(s: SessionRow): string {
  const lines: string[] = [];
  if (s.description) lines.push(s.description.trim(), "");
  if (s.sport) lines.push(`Sport: ${s.sport}`);
  if (s.location_name) {
    lines.push(`Where: ${s.location_name}${s.city ? `, ${s.city}` : ""}`);
  }
  if (s.capacity) lines.push(`Spaces: ${s.capacity}`);
  lines.push(
    `Cost: ${s.price_pence ? `£${(s.price_pence / 100).toFixed(2)}` : "Free"}`,
  );
  lines.push("");
  lines.push(
    `Book your spot on Fittrybe: https://fittrybe.co.uk/sessions/${s.id}`,
  );
  // Meetup caps descriptions. Trim well under the limit.
  return lines.join("\n").slice(0, 60000);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ error: "POST only" }, 405);

  const authHeader = req.headers.get("Authorization") ?? "";
  if (!authHeader) return json({ error: "Not signed in" }, 401);

  let sessionId: string;
  try {
    ({ sessionId } = await req.json());
    if (!sessionId) throw new Error();
  } catch {
    return json({ error: "Body must be { sessionId }" }, 400);
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;

  // 1. Who is calling. Uses the caller's own JWT so RLS still applies.
  const asUser = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
    global: { headers: { Authorization: authHeader } },
  });
  const { data: auth } = await asUser.auth.getUser();
  if (!auth?.user) return json({ error: "Not signed in" }, 401);

  // 2. Load the session with elevated rights, then check ownership ourselves.
  const admin = createClient(
    supabaseUrl,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );
  const { data: session, error } = await admin
    .from("sessions")
    .select("*")
    .eq("id", sessionId)
    .maybeSingle<SessionRow>();

  if (error) return json({ error: error.message }, 500);
  if (!session) return json({ error: "Session not found" }, 404);
  if (session.host_id !== auth.user.id) {
    return json({ error: "You are not the host of this session" }, 403);
  }

  const tz = session.timezone ?? "Europe/London";
  const groupUrlname = Deno.env.get("MEETUP_GROUP_URLNAME")!;
  const venueId = session.meetup_venue_id ??
    Deno.env.get("MEETUP_DEFAULT_VENUE_ID") ?? undefined;

  try {
    const token = await getAccessToken(credsFromEnv());
    const description = buildDescription(session);

    // Already on Meetup: update instead of creating a duplicate.
    if (session.meetup_event_id) {
      const ev = await updateEvent(token, session.meetup_event_id, {
        description,
      });
      await admin
        .from("sessions")
        .update({
          meetup_event_url: ev.eventUrl,
          meetup_synced_at: new Date().toISOString(),
          meetup_sync_error: null,
        })
        .eq("id", session.id);
      return json({ status: "updated", eventId: ev.id, url: ev.eventUrl });
    }

    const ev = await createAndPublishEvent(token, {
      groupUrlname,
      title: session.title,
      description,
      startDateTime: toMeetupLocal(session.starts_at, tz),
      duration: `PT${session.duration_minutes ?? 60}M`,
      venueId,
    });

    await admin
      .from("sessions")
      .update({
        meetup_event_id: ev.id,
        meetup_event_url: ev.eventUrl,
        meetup_synced_at: new Date().toISOString(),
        meetup_sync_error: null,
      })
      .eq("id", session.id);

    return json({ status: "published", eventId: ev.id, url: ev.eventUrl });
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e);
    await admin
      .from("sessions")
      .update({ meetup_sync_error: message })
      .eq("id", session.id);
    return json({ error: message }, 502);
  }
});
