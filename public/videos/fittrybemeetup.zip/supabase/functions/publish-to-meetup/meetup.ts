// Meetup API client for Deno / Supabase Edge Functions.
//
// Auth: JWT server-to-server flow (no member interaction at request time).
// Docs: https://www.meetup.com/api/authentication/
//       https://www.meetup.com/graphql/guide/

import { SignJWT, importPKCS8 } from "npm:jose@5";

const TOKEN_URL = "https://secure.meetup.com/oauth2/access";
const GQL_URL = "https://api.meetup.com/gql-ext";

export interface MeetupCreds {
  clientKey: string; // OAuth client key   -> iss
  memberId: string; // authorised member  -> sub
  signingKeyId: string; // private key id     -> kid
  privateKeyPem: string; // RSA private key PEM (PKCS#8)
}

export function credsFromEnv(): MeetupCreds {
  const get = (k: string) => {
    const v = Deno.env.get(k);
    if (!v) throw new Error(`Missing env var ${k}`);
    return v;
  };
  return {
    clientKey: get("MEETUP_CLIENT_KEY"),
    memberId: get("MEETUP_MEMBER_ID"),
    signingKeyId: get("MEETUP_SIGNING_KEY_ID"),
    // Store the PEM with real newlines, or with \n escapes which we unescape here.
    privateKeyPem: get("MEETUP_PRIVATE_KEY").replace(/\\n/g, "\n"),
  };
}

// Access tokens live 3600s. Cache per warm instance and refresh a minute early.
let cached: { token: string; expiresAt: number } | null = null;

export async function getAccessToken(creds: MeetupCreds): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  if (cached && cached.expiresAt - 60 > now) return cached.token;

  const key = await importPKCS8(creds.privateKeyPem, "RS256");
  const assertion = await new SignJWT({})
    .setProtectedHeader({ alg: "RS256", kid: creds.signingKeyId })
    .setIssuer(creds.clientKey)
    .setSubject(creds.memberId)
    .setAudience("api.meetup.com")
    .setIssuedAt(now)
    .setExpirationTime(now + 120)
    .sign(key);

  const res = await fetch(TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion,
    }),
  });

  const body = await res.json().catch(() => ({}));
  if (!res.ok || !body.access_token) {
    throw new Error(
      `Meetup token request failed (${res.status}): ${JSON.stringify(body)}`,
    );
  }

  cached = {
    token: body.access_token,
    expiresAt: now + (body.expires_in ?? 3600),
  };
  return cached.token;
}

export async function gql<T = unknown>(
  token: string,
  query: string,
  variables: Record<string, unknown>,
): Promise<T> {
  const res = await fetch(GQL_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ query, variables }),
  });

  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(`Meetup GraphQL HTTP ${res.status}: ${JSON.stringify(body)}`);
  }
  if (body.errors?.length) {
    throw new Error(`Meetup GraphQL: ${JSON.stringify(body.errors)}`);
  }
  return body.data as T;
}

const CREATE_EVENT = /* GraphQL */ `
  mutation FittrybeCreateEvent($input: CreateEventInput!) {
    createEvent(input: $input) {
      event {
        id
        eventUrl
      }
      errors {
        message
        code
        field
      }
    }
  }
`;

const EDIT_EVENT = /* GraphQL */ `
  mutation FittrybeEditEvent($input: EditEventInput!) {
    editEvent(input: $input) {
      event {
        id
        eventUrl
      }
      errors {
        message
        code
        field
      }
    }
  }
`;

export interface EventDraft {
  groupUrlname: string;
  title: string;
  description: string;
  /** Local wall clock time, no offset, e.g. "2026-08-20T18:00" */
  startDateTime: string;
  /** ISO 8601 duration, e.g. "PT90M" */
  duration: string;
  venueId?: string;
}

type MutationResult = {
  event: { id: string; eventUrl: string } | null;
  errors: { message: string; code: string; field: string }[] | null;
};

function unwrap(result: MutationResult, what: string) {
  if (result.errors?.length) {
    throw new Error(
      `Meetup rejected ${what}: ` +
        result.errors.map((e) => `${e.field ?? "-"}: ${e.message}`).join("; "),
    );
  }
  if (!result.event) throw new Error(`Meetup returned no event for ${what}`);
  return result.event;
}

/** Create as a draft, then publish. Meetup wants those as two calls. */
export async function createAndPublishEvent(token: string, draft: EventDraft) {
  const created = await gql<{ createEvent: MutationResult }>(
    token,
    CREATE_EVENT,
    { input: { ...draft, publishStatus: "DRAFT" } },
  );
  const event = unwrap(created.createEvent, "event creation");

  const published = await gql<{ editEvent: MutationResult }>(token, EDIT_EVENT, {
    input: { eventId: event.id, publishStatus: "PUBLISHED" },
  });
  return unwrap(published.editEvent, "event publish");
}

/** Update an event we already pushed. */
export async function updateEvent(
  token: string,
  eventId: string,
  fields: { description?: string; howToFindUs?: string },
) {
  const res = await gql<{ editEvent: MutationResult }>(token, EDIT_EVENT, {
    input: { eventId, ...fields },
  });
  return unwrap(res.editEvent, "event update");
}
