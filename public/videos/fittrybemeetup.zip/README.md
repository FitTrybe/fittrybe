# Fittrybe to Meetup

Pushes a Fittrybe session to Meetup as a published event, with one button.

```
supabase/migrations/20260812090000_meetup_sync.sql   columns + venue map
supabase/functions/publish-to-meetup/meetup.ts       auth + GraphQL client
supabase/functions/publish-to-meetup/index.ts        the edge function
app/PublishToMeetupButton.tsx                        the button
```

## 1. Get your Meetup keys

You have Pro, so you can apply. This is the only manual part.

1. Go to https://www.meetup.com/api/oauth/list/ and create an OAuth consumer.
   Redirect URI can be `https://fittrybe.co.uk/auth/meetup` even though the
   server flow does not use it.
2. Wait for approval. Meetup reviews it against their API licence terms.
3. Open the consumer, generate a **signing key**. You get:
   - a client key
   - a key id (`kid`)
   - an RSA private key, downloaded once as a `.pem` file
4. Find your member id: open your own Meetup profile, the number in the URL.

## 2. Set the secrets

```bash
supabase secrets set \
  MEETUP_CLIENT_KEY=... \
  MEETUP_MEMBER_ID=... \
  MEETUP_SIGNING_KEY_ID=... \
  MEETUP_GROUP_URLNAME=fittrybe-london \
  MEETUP_DEFAULT_VENUE_ID=... \
  SITE_ORIGIN=https://fittrybe.co.uk

# private key separately so the newlines survive
supabase secrets set MEETUP_PRIVATE_KEY="$(cat meetup-private-key.pem)"
```

`MEETUP_GROUP_URLNAME` is the bit after `meetup.com/` in your group address.

## 3. Deploy

```bash
supabase db push
supabase functions deploy publish-to-meetup
```

## 4. Drop the button in

```tsx
<PublishToMeetupButton
  sessionId={session.id}
  existingUrl={session.meetup_event_url}
/>
```

## How it works

1. Signs a short lived JWT with your RSA key and swaps it for a Meetup access
   token. No login popup, no refresh token to babysit. Tokens last an hour and
   are cached in the warm instance.
2. Loads the session, checks the caller is the host.
3. `createEvent` as a DRAFT, then `editEvent` to PUBLISHED. Meetup wants those
   as two calls.
4. Writes `meetup_event_id` and `meetup_event_url` back on the row, so pressing
   the button again updates the Meetup event instead of making a second one.

## Things to check on your first run

- **Venue.** Meetup wants a `venueId`, not a free text address. Create the
  venue once in your Meetup group, grab its id, and put it in
  `MEETUP_DEFAULT_VENUE_ID`. For sessions at other spots, fill
  `sessions.meetup_venue_id` or use the `meetup_venues` mapping table.
- **Column names.** The function expects `sessions` to have `title`, `sport`,
  `description`, `starts_at`, `duration_minutes`, `capacity`, `price_pence`,
  `location_name`, `city`, `timezone`, `host_id`. Rename in `index.ts` if
  yours differ.
- **Time zone.** Meetup takes local wall clock time with no offset. The
  function converts from your `timestamptz` using the session time zone, and
  falls back to `Europe/London`.
- **Rate limits.** Fine for hand pressed buttons. If you ever bulk sync a
  season of fixtures, add a queue and space the calls out.

## Later, if you want it fully automatic

Add a Postgres trigger on `sessions` that calls this function via
`pg_net` whenever a row is inserted or its time changes. Same code, no button.
