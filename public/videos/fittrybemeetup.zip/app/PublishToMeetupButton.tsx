"use client";

import { useState } from "react";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
);

type Props = {
  sessionId: string;
  /** Pass the saved value so the button shows the right state on load. */
  existingUrl?: string | null;
};

export default function PublishToMeetupButton({
  sessionId,
  existingUrl,
}: Props) {
  const [busy, setBusy] = useState(false);
  const [url, setUrl] = useState(existingUrl ?? null);
  const [error, setError] = useState<string | null>(null);

  async function publish() {
    setBusy(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke(
        "publish-to-meetup",
        { body: { sessionId } },
      );
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      setUrl(data.url);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-col gap-2">
      <button
        onClick={publish}
        disabled={busy}
        className="rounded-xl bg-[#ED1C40] px-4 py-2 font-semibold text-white disabled:opacity-50"
      >
        {busy
          ? "Sending..."
          : url
          ? "Update on Meetup"
          : "Publish to Meetup"}
      </button>

      {url && (
        <a
          href={url}
          target="_blank"
          rel="noreferrer"
          className="text-sm underline"
        >
          View on Meetup
        </a>
      )}

      {error && <p className="text-sm text-red-600">{error}</p>}
    </div>
  );
}
